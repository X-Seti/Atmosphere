// diary.js - Weather diary logging functions

.pragma library

function appendWeather(weatherData, notes, executable, logPath, layoutType) {
    console.log("diary.js: Weather:", JSON.stringify(weatherData))
    console.log("diary.js: appendWeather called")
    console.log("diary.js: logPath =", logPath)
    console.log("diary.js: notes =", notes)
    console.log("diary.js: weatherData =", JSON.stringify(weatherData))
    console.log("Layout:", layoutType)

    if (!executable) {
        console.error("diary.js: executable is null!")
        return
    }
    
    // Determine file path
    var filePath = logPath
    if (!filePath || filePath === "" || filePath === "/tmp") {
        filePath = "$HOME/weather_diary.txt"
    }
    
    console.log("diary.js: Writing to:", filePath)
    
    // Get current date/time
    var now = new Date()
    var dateStr = now.toISOString().slice(0, 10) // YYYY-MM-DD
    var timeStr = now.toTimeString().slice(0, 5) // HH:MM

    
    // Build entry based on layout type
    var entry = ""
    
    if (layoutType === 0) {
        // Compact

        entry = date + " " + time + " | Temp: " + weatherData.temperature + "° | Humidity: " + weatherData.humidity + "% | Pressure: " + weatherData.pressureHpa + " hPa"
        entry += "Weather: " + weatherData.condition + "\n"
        entry += "\n"
        if (notes && notes.trim() !== "") {
            entry += " | Notes: " + notes.trim()
        }
        entry += "\n"
    } else if (layoutType === 1) {
        // Detailed
        entry = "\n" + dateStr + " " + timeStr + "\n"
        entry += "Weather: " + weatherData.condition + "\n"
        entry += "Temperature: " + weatherData.temperature + "°\n"
        entry += "Humidity: " + weatherData.humidity + "%\n"
        entry += "Pressure: " + weatherData.pressureHpa + " hPa\n"
        entry += "\n"
        if (notes && notes !== "") {
            entry += "Notes: " + notes + "\n"
        }
        entry += "\n"
    } else {
        // Markdown
        entry = "\n## " + dateStr + " " + timeStr + "\n\n"
        entry += "- **Weather:** " + weatherData.condition  + "\n"
        entry += "- **Temperature:** " + weatherData.temperature + "°\n"
        entry += "- **Humidity:** " + weatherData.humidity + "%\n"
        entry += "- **Pressure:** " + weatherData.pressureHpa + " hPa\n"
        entry += "\n"
        if (notes && notes !== "") {
            entry += "\n**Notes:** " + notes + "\n"
        }
        entry += "\n"
    }
    
    /*
     * function appendWeathersimple(d) {
        var f = Qt.openFile(path(), "a")

        var now = new Date()
        var dateStr = now.toLocaleDateString(Qt.locale(), {
            weekday: "short", day: "numeric", month: "short", year: "numeric"
        })

        f.write(
            dateStr + "\n" +
            "Weather: " + d.condition + "\n" +
            "Temperature: " + Math.round(d.temperature) + "°C\n" +
            "Humidity: " + d.humidity + "%\n" +
            "Pressure: " + d.pressure + " hPa\n\n" +
            "not data entered!\n\n"
        )

        f.close()
    }
    */


    console.log("diary.js: Entry to write:", entry)
    
    // Escape single quotes in entry for shell
    var escapedEntry = entry.replace(/'/g, "'\\''")
    
    // Write to file using echo
    var cmd = "echo '" + escapedEntry + "' >> '" + filePath + "'"
    console.log("diary.js: Executing command")
    
    try {
        executable.exec(cmd)
        console.log("diary.js: Command executed successfully")
    } catch (e) {
        console.error("diary.js: Error executing command:", e.message)
    }
}
