#!/bin/bash
# File: uninstall_diary.sh
# Uninstaller for diary dialog module

WIDGET_PATH="$HOME/.local/share/plasma/plasmoids/weather.widget.plus"
MAIN_QML="$WIDGET_PATH/contents/ui/main.qml"

echo "Uninstalling diary dialog module..."

# 1. Restore original main.qml if backup exists
if [ -f "$MAIN_QML.ORIGINAL" ]; then
    echo "Restoring original main.qml..."
    cp "$MAIN_QML.ORIGINAL" "$MAIN_QML"
else
    echo "No backup found, skipping main.qml restore"
fi

# 2. Remove module files
echo "Removing module files..."
rm -f "$WIDGET_PATH/contents/code/diary.js"
rm -f "$WIDGET_PATH/contents/ui/DiaryDialog.qml"
rm -f "$WIDGET_PATH/contents/ui/config/ConfigLogs.qml"
rm -f "$WIDGET_PATH/contents/ui/config/ConfigDiary.qml"

echo "Uninstallation complete!"
echo "Reloading plasmashell..."
killall plasmashell; plasmashell &
