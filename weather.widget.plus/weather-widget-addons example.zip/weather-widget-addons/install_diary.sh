#!/bin/bash
# File: install_diary.sh
# Installer for diary dialog module

WIDGET_PATH="$HOME/.local/share/plasma/plasmoids/weather.widget.plus"
MAIN_QML="$WIDGET_PATH/contents/ui/main.qml"

echo "Installing diary dialog module..."

# 1. Backup original main.qml
if [ ! -f "$MAIN_QML.ORIGINAL" ]; then
    echo "Creating backup: main.qml.ORIGINAL"
    cp "$MAIN_QML" "$MAIN_QML.ORIGINAL"
fi

# 2. Copy module files
echo "Copying module files..."
cp diary.js "$WIDGET_PATH/contents/code/"
cp DiaryDialog.qml "$WIDGET_PATH/contents/ui/"
cp ConfigLogs.qml "$WIDGET_PATH/contents/ui/config/"
cp ConfigDiary.qml "$WIDGET_PATH/contents/ui/config/"

# 3. Check if modifications already exist
if grep -q "diary.js" "$MAIN_QML"; then
    echo "Diary module already installed in main.qml"
    echo "Reloading plasmashell..."
    killall plasmashell; plasmashell &
    exit 0
fi

# 4. Add diary.js import (after timezoneData.js import)
echo "Adding diary.js import..."
sed -i '/import.*timezoneData.js/a import "../code/diary.js" as Diary' "$MAIN_QML"

# 5. Add executable DataSource (after existing DataSource)
echo "Adding executable DataSource..."
sed -i '/Plasma5Support.DataSource {/,/^    }/{
/^    }/a\
    Plasma5Support.DataSource {\
        id: executable\
        engine: "executable"\
        connectedSources: []\
        onNewData: disconnectSource(sourceName)\
        function exec(cmd) {\
            connectSource(cmd)\
        }\
    }
}' "$MAIN_QML"

# 6. Add diary properties (after other properties, before includes)
echo "Adding diary properties..."
sed -i '/WeatherCache {/i\
    property bool diaryLoggingEnabled: plasmoid.configuration.diaryLoggingEnabled !== undefined ? plasmoid.configuration.diaryLoggingEnabled : true\
    property string diaryLogPath: plasmoid.configuration.logPath || ""\
\

' "$MAIN_QML"

# 7. Add DiaryDialog component (before closing PlasmoidItem)
echo "Adding DiaryDialog component..."
sed -i '/^}$/i\
    // === DIARY DIALOG ===\
    function showDiaryEntryDialog(weatherData) {\
        if (!diaryLoggingEnabled) return\
        diaryEntryDialog.weatherData = weatherData\
        diaryEntryDialog.open()\
    }\
\
    DiaryDialog {\
        id: diaryEntryDialog\
        executableSource: executable\
        logPath: diaryLogPath\
        layoutType: plasmoid.configuration.diaryLayoutType || 0\
    }\
\

' "$MAIN_QML"

# 8. Add context menu action (before existing Plasmoid.contextualActions if it exists)
echo "Adding context menu action..."
if grep -q "Plasmoid.contextualActions" "$MAIN_QML"; then
    # Add to existing contextualActions
    sed -i '/Plasmoid.contextualActions: \[/a\
        PlasmaCore.Action {\
            text: i18n("Add a weather notation")\
            icon.name: "document-edit"\
            onTriggered: {\
                showDiaryEntryDialog({\
                    temperature: currentWeatherModel ? currentWeatherModel.temperature : "N/A",\
                    humidity: currentWeatherModel ? currentWeatherModel.humidity : "N/A",\
                    pressureHpa: currentWeatherModel ? currentWeatherModel.pressureHpa : "N/A"\
                })\
            }\
        },' "$MAIN_QML"
else
    # Create new contextualActions
    sed -i '/^}$/i\
    Plasmoid.contextualActions: [\
        PlasmaCore.Action {\
            text: i18n("Add a weather notation")\
            icon.name: "document-edit"\
            onTriggered: {\
                showDiaryEntryDialog({\
                    temperature: currentWeatherModel ? currentWeatherModel.temperature : "N/A",\
                    humidity: currentWeatherModel ? currentWeatherModel.humidity : "N/A",\
                    pressureHpa: currentWeatherModel ? currentWeatherModel.pressureHpa : "N/A"\
                })\
            }\
        }\
    ]\
\

' "$MAIN_QML"
fi

echo "Installation complete!"
echo "Reloading plasmashell..."
killall plasmashell; plasmashell &

echo ""
echo "Test: Right-click weather widget -> 'Add a weather notation'"
