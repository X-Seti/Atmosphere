.pragma library
.import QtQuick 2.0 as QtQuick

function maybeAsk() {
    var today = new Date().toISOString().slice(0,10)

    if (plasmoid.configuration.lastPopupDate === today)
        return

    if (Qt.application.state !== Qt.ApplicationActive)
        return

    plasmoid.configuration.lastPopupDate = today

    Qt.callLater(function() {
        plasmoid.nativeInterface.showMessage(
            "Daily Diary",
            "How are you doing today?"
        )
    })
}
